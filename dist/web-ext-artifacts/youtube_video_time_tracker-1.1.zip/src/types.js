export class VideoData {
    constructor(timeWatched, totalDuration, title, percentageWatched, youtubeId) {
        this.timeWatched = timeWatched;
        this.totalDuration = totalDuration;
        this.title = title;
        this.percentageWatched = percentageWatched;
        this.youtubeId = youtubeId;
    }
}
